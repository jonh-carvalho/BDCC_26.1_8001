from decimal import Decimal

from django.test import TestCase
from rest_framework.test import APIClient

from .models import Produto


class HealthcheckTests(TestCase):
	def setUp(self):
		self.client = APIClient()

	def test_healthcheck_root_retornar_200(self):
		response = self.client.get('/')
		self.assertEqual(response.status_code, 200)
		self.assertEqual(response.json(), {'status': 'ok'})


class ProdutoApiTests(TestCase):
	def setUp(self):
		self.client = APIClient()

	def test_lista_produtos_retorna_200(self):
		Produto.objects.create(
			nome='Teclado Mecanico',
			descricao='Teclado sem fio',
			preco=Decimal('299.90'),
		)

		response = self.client.get('/api/produtos/')

		self.assertEqual(response.status_code, 200)
		self.assertEqual(len(response.json()), 1)
		self.assertEqual(response.json()[0]['nome'], 'Teclado Mecanico')
